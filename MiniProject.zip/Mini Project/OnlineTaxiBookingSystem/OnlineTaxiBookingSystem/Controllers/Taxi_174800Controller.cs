﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using OnlineTaxiBookingSystem.Models;

namespace OnlineTaxiBookingSystem.Controllers
{
    public class Taxi_174800Controller : Controller
    {
        private TaxiBookingContext db = new TaxiBookingContext();

        // GET: Taxi_174800
        public ActionResult Index()
        {
            return View(db.Taxi_174800.ToList());
        }

        // GET: Taxi_174800/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Taxi_174800 taxi_174800 = db.Taxi_174800.Find(id);
            if (taxi_174800 == null)
            {
                return HttpNotFound();
            }
            return View(taxi_174800);
        }

        // GET: Taxi_174800/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Taxi_174800/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "TaxiID,TaxiModel,Color,RegisterNumber,TaxiType")] Taxi_174800 taxi_174800)
        {
            if (ModelState.IsValid)
            {
                db.Taxi_174800.Add(taxi_174800);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(taxi_174800);
        }

        // GET: Taxi_174800/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Taxi_174800 taxi_174800 = db.Taxi_174800.Find(id);
            if (taxi_174800 == null)
            {
                return HttpNotFound();
            }
            return View(taxi_174800);
        }

        // POST: Taxi_174800/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "TaxiID,TaxiModel,Color,RegisterNumber,TaxiType")] Taxi_174800 taxi_174800)
        {
            if (ModelState.IsValid)
            {
                db.Entry(taxi_174800).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(taxi_174800);
        }

        // GET: Taxi_174800/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Taxi_174800 taxi_174800 = db.Taxi_174800.Find(id);
            if (taxi_174800 == null)
            {
                return HttpNotFound();
            }
            return View(taxi_174800);
        }

        // POST: Taxi_174800/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Taxi_174800 taxi_174800 = db.Taxi_174800.Find(id);
            db.Taxi_174800.Remove(taxi_174800);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
