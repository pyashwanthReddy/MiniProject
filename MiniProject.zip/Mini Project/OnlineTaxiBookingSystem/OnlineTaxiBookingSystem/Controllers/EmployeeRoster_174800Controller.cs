﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using OnlineTaxiBookingSystem.Models;

namespace OnlineTaxiBookingSystem.Controllers
{
    public class EmployeeRoster_174800Controller : Controller
    {
        private TaxiBookingContext db = new TaxiBookingContext();

        // GET: EmployeeRoster_174800
        public ActionResult Index()
        {
            int id = Convert.ToInt32(Session["EmployeeID"]);
            var res = db.EmployeeRoster_174800.Where(a => a.EmployeeID == id).ToList();
            return View(res);
        }
        [HttpPost]
        public ActionResult Index(int id)
        {            
            return View(db.EmployeeRoster_174800.Where(e=>e.EmployeeID==id));
        }

        // GET: EmployeeRoster_174800/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            EmployeeRoster_174800 employeeRoster_174800 = db.EmployeeRoster_174800.Find(id);
            if (employeeRoster_174800 == null)
            {
                return HttpNotFound();
            }
            return View(employeeRoster_174800);
        }

        // GET: EmployeeRoster_174800/Create
        public ActionResult Create()
        {
            ViewBag.EmployeeID = new SelectList(db.Employee_174800, "EmployeeID", "EmployeeName");
            ViewBag.BookingID = new SelectList(db.Booking_174800, "BookingID", "BookingID");
            return View();
        }

        // POST: EmployeeRoster_174800/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "RosterID,FromDate,ToDate,InTime,OutTime,EmployeeID,BookingID")] EmployeeRoster_174800 employeeRoster_174800)
        {
            if (ModelState.IsValid)
            {
                var res = db.Booking_174800.Where(a => a.BookingID == employeeRoster_174800.BookingID).FirstOrDefault();
                res.EmployeeId = employeeRoster_174800.EmployeeID;
                if(TryUpdateModel(res))
                {
                    db.SaveChanges();
                }
                db.EmployeeRoster_174800.Add(employeeRoster_174800);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.EmployeeID = new SelectList(db.Employee_174800, "EmployeeID", "EmployeeName", employeeRoster_174800.EmployeeID);
            return View(employeeRoster_174800);
        }

        // GET: EmployeeRoster_174800/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            EmployeeRoster_174800 employeeRoster_174800 = db.EmployeeRoster_174800.Find(id);
            if (employeeRoster_174800 == null)
            {
                return HttpNotFound();
            }
            ViewBag.EmployeeID = new SelectList(db.Employee_174800, "EmployeeID", "EmployeeName", employeeRoster_174800.EmployeeID);
            return View(employeeRoster_174800);
        }

        // POST: EmployeeRoster_174800/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "RosterID,FromDate,ToDate,InTime,OutTime,EmployeeID")] EmployeeRoster_174800 employeeRoster_174800)
        {
            if (ModelState.IsValid)
            {
                db.Entry(employeeRoster_174800).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.EmployeeID = new SelectList(db.Employee_174800, "EmployeeID", "EmployeeName", employeeRoster_174800.EmployeeID);
            return View(employeeRoster_174800);
        }

        // GET: EmployeeRoster_174800/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            EmployeeRoster_174800 employeeRoster_174800 = db.EmployeeRoster_174800.Find(id);
            if (employeeRoster_174800 == null)
            {
                return HttpNotFound();
            }
            return View(employeeRoster_174800);
        }

        // POST: EmployeeRoster_174800/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            EmployeeRoster_174800 employeeRoster_174800 = db.EmployeeRoster_174800.Find(id);
            db.EmployeeRoster_174800.Remove(employeeRoster_174800);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
