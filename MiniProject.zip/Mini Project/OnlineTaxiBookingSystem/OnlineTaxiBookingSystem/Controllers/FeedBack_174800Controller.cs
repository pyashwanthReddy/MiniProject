﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using OnlineTaxiBookingSystem.Models;

namespace OnlineTaxiBookingSystem.Controllers
{
    public class FeedBack_174800Controller : Controller
    {
        private TaxiBookingContext db = new TaxiBookingContext();

        // GET: FeedBack_174800
        public ActionResult Index()
        {
            var feedBack_174800 = db.FeedBack_174800.Include(f => f.Employee_174800);
            return View(feedBack_174800.ToList());
        }

        // GET: FeedBack_174800/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            FeedBack_174800 feedBack_174800 = db.FeedBack_174800.Find(id);
            if (feedBack_174800 == null)
            {
                return HttpNotFound();
            }
            return View(feedBack_174800);
        }

        // GET: FeedBack_174800/Create
        public ActionResult Create()
        {
            ViewBag.EmployeeID = new SelectList(db.Employee_174800, "EmployeeID", "EmployeeName");
            return View();
        }

        // POST: FeedBack_174800/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "ID,EmployeeID,Name,Email,Rating")] FeedBack_174800 feedBack_174800)
        {
            if (ModelState.IsValid)
            {
                db.FeedBack_174800.Add(feedBack_174800);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.EmployeeID = new SelectList(db.Employee_174800, "EmployeeID", "EmployeeName", feedBack_174800.EmployeeID);
            return View(feedBack_174800);
        }

        // GET: FeedBack_174800/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            FeedBack_174800 feedBack_174800 = db.FeedBack_174800.Find(id);
            if (feedBack_174800 == null)
            {
                return HttpNotFound();
            }
            ViewBag.EmployeeID = new SelectList(db.Employee_174800, "EmployeeID", "EmployeeName", feedBack_174800.EmployeeID);
            return View(feedBack_174800);
        }

        // POST: FeedBack_174800/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "ID,EmployeeID,Name,Email,Rating")] FeedBack_174800 feedBack_174800)
        {
            if (ModelState.IsValid)
            {
                db.Entry(feedBack_174800).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.EmployeeID = new SelectList(db.Employee_174800, "EmployeeID", "EmployeeName", feedBack_174800.EmployeeID);
            return View(feedBack_174800);
        }

        // GET: FeedBack_174800/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            FeedBack_174800 feedBack_174800 = db.FeedBack_174800.Find(id);
            if (feedBack_174800 == null)
            {
                return HttpNotFound();
            }
            return View(feedBack_174800);
        }

        // POST: FeedBack_174800/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            FeedBack_174800 feedBack_174800 = db.FeedBack_174800.Find(id);
            db.FeedBack_174800.Remove(feedBack_174800);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
