﻿using OnlineTaxiBookingSystem.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace OnlineTaxiBookingSystem.Controllers
{
    public class AccountController : Controller
    {
        // GET: Account
        public ActionResult Index()
        {
            if (Session["EmailID"] != null)
            {
                return View();
            }
            else
            {
                return RedirectToAction("Login", "Account");
            }
        }
        public ActionResult Register()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Register(Customer_174800 user)
        {
                if (ModelState.IsValid)
                {
                    using (TaxiBookingContext tbc = new TaxiBookingContext())
                    {
                        var get_user = tbc.Customer_174800.FirstOrDefault(p => p.EmailID == user.EmailID);
                        if (get_user == null)
                        {
                            //user.Password = AESCryptography.Encrypt(user.Password);
                            //user.ConfirmPassword = AESCryptography.Encrypt(user.ConfirmPassword);
                            tbc.Customer_174800.Add(user);
                            tbc.SaveChanges();
                        }
                        else
                        {
                            ViewBag.Status = false;
                            ViewBag.Message = "UserName already exists" + user.CustomerName;
                            return View();
                        }
                        ModelState.Clear();
                        ViewBag.Message = "Successfully Registered Mr. " +
                        user.CustomerName;
                        return View();
                    }

                }
            return View(user);
        }
        public ActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Login(Customer_174800 user)
        {
            ViewBag.Status = false;
            using (TaxiBookingContext tbc = new TaxiBookingContext())
            {
                try
                {
                    var get_user = tbc.Customer_174800.Single(p => p.EmailID == user.EmailID
                    && p.Password == user.Password);
                    if (get_user != null)
                    {
                        Session["UserId"] = get_user.CustomerID.ToString();
                        Session["UserName"] = get_user.EmailID.ToString();
                        Session["usertype"] = "Customer";
                        return RedirectToAction("LoggedIn");
                    }
                    else
                    {

                        ViewBag.Message("", "UserName or Password does not match.");
                    }
                }
                catch(SystemException ex)
                {
                    ViewBag.Message = "UserName or Password does not match.";
                }
            }
            return View();
        }
        public ActionResult LoggedIn()
        {
            object obj = Session["UserName"];
            if (obj != null)
            {
                return RedirectToAction("Book", "Booking_174800");
            }
            else
            {
                return RedirectToAction("Login");
            }

        }
        public ActionResult Changepassword()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Changepassword(Customer_174800 user)
        {
            using (TaxiBookingContext db = new TaxiBookingContext())
            {
                var detail = db.Customer_174800.Where(log=> log.EmailID == user.EmailID).FirstOrDefault();
                if (detail != null)
                {
                    detail.Password = user.Password;
                    detail.ConfirmPassword=user.Password;

                    db.SaveChanges();
                    ViewBag.Message = "Record Inserted Successfully!";

                }
                else
                {
                    ViewBag.Message = "Password not Updated!";
                }


            }

            return View(user);
        }
        public ActionResult Logoff()
        {
            Session.Clear();
            Session.Abandon();
            return RedirectToAction("Login", "Account");
        }

    }
}