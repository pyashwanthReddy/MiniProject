﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using OnlineTaxiBookingSystem.Models;

namespace OnlineTaxiBookingSystem.Controllers
{
    public class Booking_174800Controller : Controller
    {
        private TaxiBookingContext db = new TaxiBookingContext();
        public ActionResult Book()
        {
            return View();
        }

        // GET: Booking_174800
        public ActionResult Index()
        {
            //var booking_174800 = db.Booking_174800.Include(b => b.Customer_174800).Include(b => b.Taxi_174800);
            //return View(booking_174800.ToList());
            if(Session["usertype"].ToString() == "Customer")
            {
                int id = Convert.ToInt32(Session["UserId"]);
                var res = db.Booking_174800.Where(a => a.CustomerID == id).ToList();
                return View(res);
            }
            else if (Session["usertype"].ToString() == "Employee")
            {
                int id = Convert.ToInt32(Session["EmployeeID"]);
                var res = db.Booking_174800.Where(a => a.EmployeeId == id).ToList();
                return View(res);
            }
            return View();
        }
        [HttpPost]
        public ActionResult Index(int id)
        {

            return View(db.Booking_174800.Where(e => e.TaxiID == id));
        }

        // GET: Booking_174800/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Booking_174800 booking_174800 = db.Booking_174800.Find(id);
            if (booking_174800 == null)
            {
                return HttpNotFound();
            }
            return View(booking_174800);
        }

        // GET: Booking_174800/Create
        public ActionResult Create()
        {
            
            ViewBag.CustomerID = new SelectList(db.Customer_174800, "CustomerID", "CustomerName");
            ViewBag.TaxiID = new SelectList(db.Taxi_174800, "TaxiID", "TaxiModel");
            return View();
        }

        // POST: Booking_174800/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "BookingID,TaxiID,CustomerID,BookingDate,TripDate,StartTime,EndTime,SourceAddress,DestinationAddress,EmployeeId")] Booking_174800 booking_174800)
        {
           
                if (ModelState.IsValid)
                {
                    db.Booking_174800.Add(booking_174800);
                    db.SaveChanges();
                    return RedirectToAction("Thankyou", new { sourceAddress = booking_174800.SourceAddress, destinationAddress = booking_174800.DestinationAddress, bookingid = booking_174800.BookingID });
                }

                ViewBag.CustomerID = new SelectList(db.Customer_174800, "CustomerID", "CustomerName", booking_174800.CustomerID);
                ViewBag.TaxiID = new SelectList(db.Taxi_174800, "TaxiID", "TaxiModel", booking_174800.TaxiID);
                return View(booking_174800);
          
           
        }

        public ActionResult Thankyou(string sourceAddress, string destinationAddress,int bookingid)
        {
            if (sourceAddress != null && destinationAddress != null)
            {
                ViewBag.Source = sourceAddress;
                ViewBag.Destination = destinationAddress;
                ViewBag.ID = bookingid;
                return View();
            }
            return RedirectToAction("Create");
        }

        public ActionResult GetFareDetails()
        {

            return View();

         
        }
        // GET: Booking_174800/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Booking_174800 booking_174800 = db.Booking_174800.Find(id);
            if (booking_174800 == null)
            {
                return HttpNotFound();
            }
            ViewBag.CustomerID = new SelectList(db.Customer_174800, "CustomerID", "CustomerName", booking_174800.CustomerID);
            ViewBag.TaxiID = new SelectList(db.Taxi_174800, "TaxiID", "TaxiModel", booking_174800.TaxiID);
            return View(booking_174800);
        }

        // POST: Booking_174800/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "BookingID,TaxiID,CustomerID,BookingDate,TripDate,StartTime,EndTime,SourceAddress,DestinationAddress")] Booking_174800 booking_174800)
        {
            if (ModelState.IsValid)
            {
                db.Entry(booking_174800).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.CustomerID = new SelectList(db.Customer_174800, "CustomerID", "CustomerName", booking_174800.CustomerID);
            ViewBag.TaxiID = new SelectList(db.Taxi_174800, "TaxiID", "TaxiModel", booking_174800.TaxiID);
            return View(booking_174800);
        }

        // GET: Booking_174800/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Booking_174800 booking_174800 = db.Booking_174800.Find(id);
            if (booking_174800 == null)
            {
                return HttpNotFound();
            }
            return View(booking_174800);
        }

        // POST: Booking_174800/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Booking_174800 booking_174800 = db.Booking_174800.Find(id);
            db.Booking_174800.Remove(booking_174800);
            db.SaveChanges();
            return RedirectToAction("Index");
        }
        

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
