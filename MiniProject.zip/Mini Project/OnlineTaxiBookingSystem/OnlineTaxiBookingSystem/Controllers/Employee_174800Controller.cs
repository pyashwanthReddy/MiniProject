﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using OnlineTaxiBookingSystem.Models;

namespace OnlineTaxiBookingSystem.Controllers
{
    public class Employee_174800Controller : Controller
    {
        private TaxiBookingContext db = new TaxiBookingContext();

        public ActionResult Menu()
        {
            return View();
        }
        public ActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Login(Customer_174800 user)
        {
            ViewBag.Status = false;
            using (TaxiBookingContext tbc = new TaxiBookingContext())
            {
                try
                {
                    var get_user = tbc.Employee_174800.Single(p => p.EmailID == user.EmailID
                    && p.Password == user.Password);
                    if (get_user != null)
                    {
                      
                        Session["EmployeeID"] = get_user.EmployeeID.ToString();
                        Session["usertype"] = "Employee";

                        return RedirectToAction("Menu","Employee_174800");
                    }
                    else
                    {

                        ViewBag.Message("", "UserName or Password does not match.");
                    }
                }
                catch (SystemException ex)
                {
                    ViewBag.Message = "UserName or Password does not match.";
                }
            }
            return View();
        }
        // GET: Employee_174800
        public ActionResult Index()
        {
            return View(db.Employee_174800.ToList());
        }

        // GET: Employee_174800/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Employee_174800 employee_174800 = db.Employee_174800.Find(id);
            if (employee_174800 == null)
            {
                return HttpNotFound();
            }
            return View(employee_174800);
        }

        // GET: Employee_174800/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Employee_174800/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "EmployeeID,EmployeeName,Designation,PhoneNumber,EmailID,Address,DrivingLicenseNumber,Password")] Employee_174800 employee_174800)
        {
            if (ModelState.IsValid)
            {
                db.Employee_174800.Add(employee_174800);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(employee_174800);
        }

        // GET: Employee_174800/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Employee_174800 employee_174800 = db.Employee_174800.Find(id);
            if (employee_174800 == null)
            {
                return HttpNotFound();
            }
            return View(employee_174800);
        }

        // POST: Employee_174800/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "EmployeeID,EmployeeName,Designation,PhoneNumber,EmailID,Address,DrivingLicenseNumber,Password")] Employee_174800 employee_174800)
        {
            if (ModelState.IsValid)
            {
                db.Entry(employee_174800).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(employee_174800);
        }

        // GET: Employee_174800/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Employee_174800 employee_174800 = db.Employee_174800.Find(id);
            if (employee_174800 == null)
            {
                return HttpNotFound();
            }
            return View(employee_174800);
        }

        // POST: Employee_174800/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Employee_174800 employee_174800 = db.Employee_174800.Find(id);
            db.Employee_174800.Remove(employee_174800);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
