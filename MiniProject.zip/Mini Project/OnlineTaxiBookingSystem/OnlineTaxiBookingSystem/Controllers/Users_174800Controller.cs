﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using OnlineTaxiBookingSystem.Models;

namespace OnlineTaxiBookingSystem.Controllers
{
    public class Users_174800Controller : Controller
    {
        private TaxiBookingContext db = new TaxiBookingContext();

        public ActionResult Lists()
        {
            return View();
        }
        // GET: Users_174800
        public ActionResult Index()
        {
            var users_174800 = db.Users_174800.Include(u => u.Customer_174800).Include(u => u.Employee_174800);
            return View(users_174800.ToList());
        }
        public ActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Login(Users_174800 user)
        {
            ViewBag.Status = false;
            using (TaxiBookingContext tbc = new TaxiBookingContext())
            {
                try
                {
                    var get_user = tbc.Users_174800.Single(p => p.LoginID == user.LoginID
                    && p.Password == user.Password);
                    if (get_user != null)
                    {
                        Session["UserId"] = get_user.CustomerID.ToString();
                        Session["UserName"] = get_user.LoginID.ToString();

                        return RedirectToAction("Lists");
                    }
                    else
                    {
                        ViewBag.Message("", "UserName or Password does not match.");
                    }
                }
                catch(SystemException ex)
                {
                    ViewBag.Message = "UserName or Password does not match.";
                }
            }
            return View();
        }
        public ActionResult Logoff()
        {
            Session.Clear();
            Session.Abandon();
            return RedirectToAction("Login", "Users_174800");
        }

        // GET: Users_174800/Details/5
        public ActionResult Details(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Users_174800 users_174800 = db.Users_174800.Find(id);
            if (users_174800 == null)
            {
                return HttpNotFound();
            }
            return View(users_174800);
        }

        // GET: Users_174800/Create
        public ActionResult Create()
        {
            ViewBag.CustomerID = new SelectList(db.Customer_174800, "CustomerID", "CustomerName");
            ViewBag.EmployeeID = new SelectList(db.Employee_174800, "EmployeeID", "EmployeeName");
            return View();
        }

        // POST: Users_174800/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "LoginID,Password,EmployeeID,CustomerID,Role")] Users_174800 users_174800)
        {
            if (ModelState.IsValid)
            {
                db.Users_174800.Add(users_174800);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.CustomerID = new SelectList(db.Customer_174800, "CustomerID", "CustomerName", users_174800.CustomerID);
            ViewBag.EmployeeID = new SelectList(db.Employee_174800, "EmployeeID", "EmployeeName", users_174800.EmployeeID);
            return View(users_174800);
        }

        // GET: Users_174800/Edit/5
        public ActionResult Edit(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Users_174800 users_174800 = db.Users_174800.Find(id);
            if (users_174800 == null)
            {
                return HttpNotFound();
            }
            ViewBag.CustomerID = new SelectList(db.Customer_174800, "CustomerID", "CustomerName", users_174800.CustomerID);
            ViewBag.EmployeeID = new SelectList(db.Employee_174800, "EmployeeID", "EmployeeName", users_174800.EmployeeID);
            return View(users_174800);
        }

        // POST: Users_174800/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "LoginID,Password,EmployeeID,CustomerID,Role")] Users_174800 users_174800)
        {
            if (ModelState.IsValid)
            {
                db.Entry(users_174800).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.CustomerID = new SelectList(db.Customer_174800, "CustomerID", "CustomerName", users_174800.CustomerID);
            ViewBag.EmployeeID = new SelectList(db.Employee_174800, "EmployeeID", "EmployeeName", users_174800.EmployeeID);
            return View(users_174800);
        }

        // GET: Users_174800/Delete/5
        public ActionResult Delete(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Users_174800 users_174800 = db.Users_174800.Find(id);
            if (users_174800 == null)
            {
                return HttpNotFound();
            }
            return View(users_174800);
        }

        // POST: Users_174800/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(string id)
        {
            Users_174800 users_174800 = db.Users_174800.Find(id);
            db.Users_174800.Remove(users_174800);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
